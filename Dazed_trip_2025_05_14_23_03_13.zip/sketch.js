let estado = "cidade"; // Alternar entre "cidade" e "campo"

function setup() {
  createCanvas(600, 400);
}

function draw() {
  if (estado === "cidade") {
    desenharCidade();
  } else {
    desenharCampo();
  }
}

function desenharCidade() {
  background(50, 50, 150);
  
  // Desenhando prédios
  fill(100);
  rect(50, 200, 100, 200);
  rect(200, 150, 120, 250);
  rect(400, 180, 100, 220);
  
  // Janelas
  fill(255, 204, 0);
  for (let i = 60; i < 140; i += 30) {
    rect(i, 220, 10, 10);
    rect(i, 250, 10, 10);
  }
  
  // Carros
  fill(255, 0, 0);
  rect(300, 350, 50, 20);
  fill(0);
  ellipse(310, 370, 10, 10);
  ellipse(340, 370, 10, 10);
  
  fill(255);
  textSize(20);
  textAlign(CENTER);
  text("Pressione ESPAÇO para ir ao campo", width / 2, 30);
}

function desenharCampo() {
  background(30, 150, 50);
  
  // Céu
  fill(135, 206, 250);
  rect(0, 0, width, 200);
  
  // Árvores
  fill(34, 139, 34);
  ellipse(100, 250, 60, 60);
  ellipse(300, 270, 70, 70);
  ellipse(500, 240, 50, 50);
  
  fill(139, 69, 19);
  rect(95, 280, 10, 40);
  rect(295, 290, 10, 50);
  rect(495, 260, 10, 30);
  
  // Sol
  fill(255, 204, 0);
  ellipse(550, 50, 60, 60);
  
  fill(255);
  textSize(20);
  textAlign(CENTER);
  text("Pressione ESPAÇO para ir à cidade", width / 2, 30);
}

function keyPressed() {
  if (key === ' ') {
    estado = estado === "cidade" ? "campo" : "cidade";
  }
}